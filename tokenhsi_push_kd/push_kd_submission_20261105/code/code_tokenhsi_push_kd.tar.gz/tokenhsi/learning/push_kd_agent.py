"""PUSH-only PPO/critic/AMP with old-task on-policy KL supervision."""
import copy
import hashlib
import json
import os
from pathlib import Path
import torch
from torch import nn
from rl_games.algos_torch import torch_ext
from rl_games.algos_torch.running_mean_std import RunningMeanStd
from learning.transformer.trans_agent import TransAgent
from learning.transformer.amp_network_builder_transformer import AMPTransformerMultiTaskBuilder
from learning.amp_models import ModelAMPContinuous
from learning.push_kd_losses import gaussian_forward_kl, masked_mean, push_advantages, teacher_observation, normalize_policy
from learning.push_kd_losses import gaussian_forward_kl_per_sample, lagrange_kd_loss, adapt_coefficient, feature_distill_loss

KD_TASKS = ('sit', 'carry', 'climb')
KD_TASK_ONEHOT = slice(393, 396)  # 397D obs one-hot: traj 392, sit 393, carry 394, climb 395, push 396
import yaml


class PushKDAgent(TransAgent):
    def __init__(self, base_name, config):
        super().__init__(base_name, config)
        if self.is_rnn or self.multi_gpu or self.has_central_value or self._enable_eps_greedy:
            raise ValueError('PUSH KD supports feed-forward, single GPU, stochastic PPO only')
        self._kd_coef = float(config.get('kd_coef', .001))
        if not 0 <= self._kd_coef < float('inf'):
            raise ValueError('kd_coef must be finite and nonnegative')
        # kd_mode 'fixed' (default): one constant kd_coef. 'lagrange': one coefficient per old task
        # (sit, carry, climb), starting at kd_coef and adapted each epoch toward KL <= kd_target_kl.
        self._kd_mode = config.get('kd_mode', 'fixed')
        if self._kd_mode not in ('fixed', 'lagrange'):
            raise ValueError('kd_mode must be fixed or lagrange')
        if self._kd_mode == 'lagrange':
            self._kd_target = float(config['kd_target_kl'])
            self._kd_factor = float(config.get('kd_adapt_factor', 2.0))
            self._kd_tolerance = float(config.get('kd_adapt_tolerance', 1.5))
            self._kd_bounds = (float(config.get('kd_coef_min', 1e-4)), float(config.get('kd_coef_max', 10.0)))
            if not (self._kd_target > 0 and self._kd_factor > 1 and self._kd_tolerance > 1):
                raise ValueError('lagrange KD needs kd_target_kl > 0, kd_adapt_factor > 1, kd_adapt_tolerance > 1')
            self._kd_lambda = torch.full((len(KD_TASKS),), self._kd_coef, device=self.ppo_device)
            self._kd_epoch_kl = torch.zeros(len(KD_TASKS), device=self.ppo_device)
            self._kd_epoch_count = torch.zeros(len(KD_TASKS), device=self.ppo_device)
        path = Path(config['teacher_checkpoint'])
        self._teacher_sha = hashlib.sha256(path.read_bytes()).hexdigest()
        teacher = torch.load(path, map_location=self.ppo_device, weights_only=True)
        params = yaml.safe_load(Path('tokenhsi/data/cfg/train/rlg/amp_imitation_task_transformer_multi_task.yaml').read_text())['params']
        info = dict(onehot_size=4, tota_subtask_obs_size=127, each_subtask_obs_size=[20,38,42,27], each_subtask_obs_indx=[0,20,58,100,127], each_subtask_name=['traj','sit','carry','climb'], enable_task_mask_obs=True)
        builder = AMPTransformerMultiTaskBuilder()
        builder.load(params['network'])
        self._teacher = ModelAMPContinuous.Network(builder.build('amp', actions_num=32, input_shape=(354,), num_seqs=1, amp_input_shape=(1330,), self_obs_size=223, task_obs_size=131, multi_task_info=info, device=self.ppo_device)).to(self.ppo_device)
        self._teacher.load_state_dict(teacher['model'], strict=True)
        self._teacher.eval().requires_grad_(False)
        self._teacher_rms = RunningMeanStd((354,)).to(self.ppo_device)
        self._teacher_rms.load_state_dict(teacher['running_mean_std'])
        self._teacher_rms.eval().requires_grad_(False)
        initial = torch.load(config['initial_checkpoint'], map_location=self.ppo_device, weights_only=True)
        self.model.load_state_dict(initial['model'], strict=True)
        self.running_mean_std.load_state_dict(initial['running_mean_std'])
        self._amp_input_mean_std.load_state_dict(initial['amp_input_mean_std'])
        self.value_mean_std.load_state_dict(initial['reward_mean_std'])
        task = self.vec_env.env.task
        contract_env = copy.deepcopy(task.cfg['env'])
        contract_env.pop('checkpoint', None)
        self._contract = dict(version=2, teacher_sha256=self._teacher_sha, kd_coef=self._kd_coef, reference_26k=task.cfg['env']['push']['reference_checkpoint_sha256'], env=contract_env, scene='reference_2humans_4boxes_plus_native_kd', ppo='push_only', amp='push_only')
        # Feature distillation (off by default): on old-task rows, also match the transformer output at the
        # summary (weight) token, the 64-d input of the action composer, to the frozen teacher's. Training only;
        # captured with forward hooks, so the network and the saved policy are unchanged.
        self._kd_feature_coef = float(config.get('kd_feature_coef', 0.0))
        if self._kd_feature_coef > 0:
            self._features = {}
            def capture(name):
                def hook(module, inputs, output):
                    self._features[name] = output[:, 0]
                return hook
            self.model.a2c_network.transformer_encoder.register_forward_hook(capture('student'))
            self._teacher.a2c_network.transformer_encoder.register_forward_hook(capture('teacher'))
            self._feature_size = self._teacher.a2c_network.weight_token.shape[-1]
            self._contract.update(kd_feature_coef=self._kd_feature_coef, kd_feature='transformer_output_summary_token')
        if self._kd_mode == 'lagrange':  # fixed-mode contract stays as before so existing runs still resume
            self._contract.update(kd_mode='lagrange', kd_target_kl=self._kd_target, kd_adapt_factor=self._kd_factor,
                                  kd_adapt_tolerance=self._kd_tolerance, kd_coef_bounds=list(self._kd_bounds))
        self._contract['reference_environment'] = yaml.safe_load(Path('tokenhsi/data/cfg/multi_task/push_reference.yaml').read_text())
        self._contract['reference_source_sha256'] = hashlib.sha256(Path('push_reference/PROVENANCE.json').read_bytes()).hexdigest()
        Path(self.experiment_dir, 'method_contract.json').write_text(json.dumps(self._contract, indent=2, default=str))
        # Memory fix (on by default; PUSH_KD_AMP_USED_ROWS=0 restores the original sampling). The original draws
        # batch_size demo and replay rows per epoch (about 1 GB each here, OOM on 24 GB at epoch 2), and each
        # minibatch then reads amp_minibatch_size of them at shuffled AMPDataset indices. That is a fresh
        # without-replacement draw of amp_minibatch_size rows per minibatch, so draw exactly that from the buffers
        # in calc_gradients and keep demo/replay out of the dataset. Only the RNG draws differ.
        # The buffers are built later, in init_tensors (amp_agent._build_amp_buffers); they are wrapped there.
        self._amp_used_rows = os.environ.get('PUSH_KD_AMP_USED_ROWS', '1') == '1'

    def _amp_rows(self, count):
        # the per-epoch batch_size draw in amp_agent.train_epoch is unused when the fix is on; keep it small
        return self._amp_minibatch_size if self._amp_used_rows and count == self.batch_size else count

    def _limit_sample(self, sample):
        return lambda count: sample(self._amp_rows(count))

    def _amp_minibatch(self):
        """Fresh demo and replay rows for one minibatch (memory fix); first epoch has no replay yet: PUSH samples."""
        count = self._amp_minibatch_size
        demo = self._amp_obs_demo_buffer.sample(count)['amp_obs'].to(self.ppo_device, non_blocking=True)
        if self._amp_replay_buffer.get_total_count() == 0:
            replay = self._sample_push_amp(count)
        else:
            replay = self._amp_replay_buffer.sample(count)['amp_obs'].to(self.ppo_device, non_blocking=True)
        return demo, replay

    def init_tensors(self):
        super().init_tensors()
        if self._amp_used_rows:
            for buffer in (self._amp_obs_demo_buffer, self._amp_replay_buffer):
                buffer.sample = self._limit_sample(buffer.sample)
            print('PUSH_KD_AMP_USED_ROWS: demo/replay drawn per minibatch ({} rows each) instead of {} rows per epoch'.format(
                self._amp_minibatch_size, self.batch_size), flush=True)
            # Keep the two 200k-row AMP buffers (about 1.07 GB each) in CPU RAM; each minibatch moves only its
            # amp_minibatch_size rows to the GPU. Their storage is created at the first store, after this point.
            if os.environ.get('PUSH_KD_AMP_BUFFERS_ON_CPU', '1') == '1':
                for buffer in (self._amp_obs_demo_buffer, self._amp_replay_buffer):
                    assert buffer._data_buf is None
                    buffer._device = 'cpu'
                print('PUSH_KD_AMP_BUFFERS_ON_CPU: AMP demo and replay buffers kept in CPU memory', flush=True)
        self.update_list = list(self.update_list)
        shape = self.experience_buffer.obs_base_shape
        for key in ('teacher_mu', 'teacher_sigma'):
            self.experience_buffer.tensor_dict[key] = torch.zeros(shape+(self.actions_num,), device=self.ppo_device)
            self.tensor_list.append(key)
            self.update_list.append(key)
        self.experience_buffer.tensor_dict['kd_mask'] = torch.zeros(shape, dtype=torch.bool, device=self.ppo_device)
        self.tensor_list.append('kd_mask')
        self.update_list.append('kd_mask')
        if self._kd_feature_coef > 0:
            self.experience_buffer.tensor_dict['teacher_feature'] = torch.zeros(shape+(self._feature_size,), device=self.ppo_device)
            self.tensor_list.append('teacher_feature')
            self.update_list.append('teacher_feature')

    def _preproc_obs(self, obs):
        return normalize_policy(obs, self.running_mean_std, 5) if self.normalize_input else obs

    def _preproc_amp_obs(self, obs):
        labels = obs.view(-1, 134)[:, -5:].clone()
        result = super()._preproc_amp_obs(obs)
        result.view(-1, 134)[:, -5:] = labels
        return result

    def get_action_values(self, obs_dict, rand_action_probs):
        result = super().get_action_values(obs_dict, rand_action_probs)
        if (obs_dict['obs'][:, 392] > .5).any():
            raise RuntimeError('TRAJ samples must not enter PUSH KD training')
        old = self.vec_env.env.task.kd_mask
        result['kd_mask'] = old
        result['teacher_mu'] = torch.zeros_like(result['mus'])
        # fixed_sigma: 'sigmas' is one [actions] vector, so size per-row buffers from 'mus'
        result['teacher_sigma'] = torch.ones_like(result['mus'])
        if self._kd_feature_coef > 0:
            result['teacher_feature'] = result['mus'].new_zeros(len(result['mus']), self._feature_size)
        with torch.no_grad():
            if old.any():
                raw = teacher_observation(obs_dict['obs'][old])
                normalized = normalize_policy(raw, self._teacher_rms, 4)
                mu, logstd = self._teacher.a2c_network.eval_actor(normalized, raw)
                result['teacher_mu'][old] = mu
                result['teacher_sigma'][old] = logstd.exp().expand_as(mu)
                if self._kd_feature_coef > 0:  # captured by the teacher hook during eval_actor
                    result['teacher_feature'][old] = self._features['teacher']
        # Used by inherited GAE advantage normalization and actor masking.
        result['rand_action_mask'] *= (obs_dict['obs'][:, -1] > .5).float()
        return result

    def play_steps(self):
        batch = super().play_steps()
        push = batch['obses'][:, -1] > .5
        self._push_agent_samples = batch['amp_obs'][push].detach()
        if not len(self._push_agent_samples):
            raise RuntimeError('No PUSH experience in rollout')
        self._rollout_push_mask = push
        return batch

    def _sample_push_amp(self, count):
        x = self._push_agent_samples
        return x[torch.randint(len(x), (count,), device=x.device)]

    def _calc_amp_rewards(self, obs):
        shape = obs.shape[:-1]
        flat = obs.reshape(-1, obs.shape[-1])
        push = flat[:, 133] > .5
        result = flat.new_zeros(len(flat), 1)
        if push.any():
            result[push] = self._calc_disc_rewards(flat[push])
        return dict(disc_rewards=result.reshape(*shape, 1))

    def _combine_rewards(self, task_rewards, amp_rewards):
        # The rollout mask is read from the same pre-step policy task labels.
        push = self.experience_buffer.tensor_dict['obses'][..., -1:] > .5
        return super()._combine_rewards(task_rewards, amp_rewards)*push

    def prepare_dataset(self, batch):
        push = batch['obses'][:, -1] > .5
        values, returns = batch['values'], batch['returns']
        advantages = push_advantages(returns, values, push, self.normalize_advantage)
        if self.normalize_value:
            self.value_mean_std.train()
            self.value_mean_std(values[push])
            self.value_mean_std(returns[push])
            self.value_mean_std.eval()
            values, returns = self.value_mean_std(values), self.value_mean_std(returns)
        data = dict(old_values=values, returns=returns, advantages=advantages, old_logp_actions=batch['neglogpacs'], actions=batch['actions'], obs=batch['obses'], mu=batch['mus'], sigma=batch['sigmas'], rnn_states=None, rnn_masks=None)
        amp_keys = ('amp_obs',) if self._amp_used_rows else ('amp_obs','amp_obs_demo','amp_obs_replay')
        feature_keys = ('teacher_feature',) if self._kd_feature_coef > 0 else ()
        for k in amp_keys + ('rand_action_mask','teacher_mu','teacher_sigma','kd_mask') + feature_keys:
            data[k] = batch[k]
        data['push_mask'] = push
        # First epoch has no replay yet: substitute ONLY PUSH samples.
        if not self._amp_used_rows and self._amp_replay_buffer.get_total_count() == 0:
            data['amp_obs_replay'] = self._sample_push_amp(len(push))
        self.dataset.update_values_dict(data)

    def _store_replay_amp_obs(self, obs):
        super()._store_replay_amp_obs(obs[obs[:, 133] > .5])

    def get_full_state_weights(self):
        weights = super().get_full_state_weights()
        weights['push_kd_contract'] = self._contract
        if self._kd_mode == 'lagrange':
            weights['kd_lambda'] = self._kd_lambda.detach().cpu().clone()
        return weights

    def set_full_state_weights(self, weights):
        if weights.get('push_kd_contract') != self._contract:
            raise ValueError('PUSH KD resume contract mismatch')
        super().set_full_state_weights(weights)
        if self._kd_mode == 'lagrange':
            self._kd_lambda = weights['kd_lambda'].to(self.ppo_device).clone()

    def train_epoch(self):
        if os.environ.get('PUSH_KD_GPU_MEM_GB') and torch.cuda.is_available():
            # Under a cache cap the allocator can fail on fragmentation alone (C hit OOM at 8.6 GB allocated,
            # 13.75 GB reserved, cap 14), so drop unused cached blocks once per epoch. Computation is unchanged.
            torch.cuda.empty_cache()
        info = super().train_epoch()
        if torch.cuda.is_available():
            # PyTorch peak allocation of this epoch (what a per-process cache cap must exceed) and current reservation
            info['gpu_peak_allocated_gb'] = torch.cuda.max_memory_allocated() / 2**30
            info['gpu_reserved_gb'] = torch.cuda.memory_reserved() / 2**30
            torch.cuda.reset_peak_memory_stats()
            print('GPU_MEM peak_allocated {:.2f} GB reserved {:.2f} GB'.format(
                info['gpu_peak_allocated_gb'], info['gpu_reserved_gb']), flush=True)
        if self._kd_mode == 'lagrange':
            # Epoch-mean KL per task over all minibatch updates of this epoch, then the dual step.
            kl = torch.where(self._kd_epoch_count > 0, self._kd_epoch_kl / self._kd_epoch_count.clamp_min(1),
                             torch.full_like(self._kd_epoch_kl, float('nan')))
            info['kd_task_kl'] = kl.clone()
            self._kd_lambda = adapt_coefficient(self._kd_lambda, kl, self._kd_target, self._kd_factor,
                                                self._kd_tolerance, *self._kd_bounds)
            info['kd_lambda'] = self._kd_lambda.clone()
            self._kd_epoch_kl.zero_()
            self._kd_epoch_count.zero_()
        return info

    def _log_train_info(self, info, frame):
        super()._log_train_info(info, frame)
        self.writer.add_scalar('distill/teacher_kl', torch_ext.mean_list(info['teacher_kl']).item(), frame)
        self.writer.add_scalar('distill/coefficient', self._kd_coef, frame)
        if 'feature_mse' in info:
            self.writer.add_scalar('distill/feature_mse', torch_ext.mean_list(info['feature_mse']).item(), frame)
        if 'gpu_peak_allocated_gb' in info:
            self.writer.add_scalar('memory/peak_allocated_gb', info['gpu_peak_allocated_gb'], frame)
            self.writer.add_scalar('memory/reserved_gb', info['gpu_reserved_gb'], frame)
        if self._kd_mode == 'lagrange':
            for i, name in enumerate(KD_TASKS):
                self.writer.add_scalar('distill/lambda_'+name, info['kd_lambda'][i].item(), frame)
                if not torch.isnan(info['kd_task_kl'][i]):
                    self.writer.add_scalar('distill/kl_'+name, info['kd_task_kl'][i].item(), frame)
        self.writer.add_scalar('samples/push_rollout', self._rollout_push_mask.sum().item(), frame)
        self.writer.add_scalar('samples/kd_rollout', self.vec_env.env.task.kd_mask.sum().item()*self.horizon_length, frame)

    def calc_gradients(self, input_dict):
        self.set_train()

        value_preds_batch = input_dict['old_values']
        old_action_log_probs_batch = input_dict['old_logp_actions']
        advantage = input_dict['advantages']
        old_mu_batch = input_dict['mu']
        old_sigma_batch = input_dict['sigma']
        return_batch = input_dict['returns']
        actions_batch = input_dict['actions']
        obs_batch = input_dict['obs']
        obs_batch = self._preproc_obs(obs_batch)

        amp_obs = self._sample_push_amp(self._amp_minibatch_size)
        amp_obs = self._preproc_amp_obs(amp_obs)
        if getattr(self, '_amp_used_rows', False):
            amp_obs_demo, amp_obs_replay = self._amp_minibatch()
        else:
            amp_obs_replay = input_dict['amp_obs_replay'][0:self._amp_minibatch_size]
            amp_obs_demo = input_dict['amp_obs_demo'][0:self._amp_minibatch_size]
        amp_obs_replay = self._preproc_amp_obs(amp_obs_replay)

        amp_obs_demo = self._preproc_amp_obs(amp_obs_demo)
        amp_obs_demo.requires_grad_(True)
        
        rand_action_mask = input_dict['rand_action_mask']
        rand_action_sum = torch.sum(rand_action_mask).clamp_min(1)

        lr = self.last_lr
        kl = 1.0
        lr_mul = 1.0
        curr_e_clip = lr_mul * self.e_clip

        batch_dict = {
            'is_train': True,
            'prev_actions': actions_batch, 
            'obs' : obs_batch,
            'not_normalized_obs': input_dict['obs'],
            'amp_obs' : amp_obs,
            'amp_obs_replay' : amp_obs_replay,
            'amp_obs_demo' : amp_obs_demo
        }

        rnn_masks = None
        if self.is_rnn:
            rnn_masks = input_dict['rnn_masks']
            batch_dict['rnn_states'] = input_dict['rnn_states']
            batch_dict['seq_length'] = self.seq_len

        with torch.cuda.amp.autocast(enabled=self.mixed_precision):
            res_dict = self.model(batch_dict)
            action_log_probs = res_dict['prev_neglogp']
            values = res_dict['values']
            entropy = res_dict['entropy']
            mu = res_dict['mus']
            # fixed_sigma returns one [actions] vector; expand so row masks below can index it
            sigma = res_dict['sigmas'].expand_as(mu)
            disc_agent_logit = res_dict['disc_agent_logit']
            disc_agent_replay_logit = res_dict['disc_agent_replay_logit']
            disc_demo_logit = res_dict['disc_demo_logit']

            a_info = self._actor_loss(old_action_log_probs_batch, action_log_probs, advantage, curr_e_clip)
            a_loss = a_info['actor_loss']
            a_clipped = a_info['actor_clipped'].float()

            c_info = self._critic_loss(value_preds_batch, values, curr_e_clip, return_batch, self.clip_value)
            c_loss = c_info['critic_loss']

            b_loss = self.bound_loss(mu)
            
            c_loss = masked_mean(c_loss, input_dict['push_mask'])
            a_loss = torch.sum(rand_action_mask * a_loss) / rand_action_sum
            entropy = torch.sum(rand_action_mask * entropy) / rand_action_sum
            b_loss = torch.sum(rand_action_mask * b_loss) / rand_action_sum
            a_clip_frac = torch.sum(rand_action_mask * a_clipped) / rand_action_sum

            disc_agent_cat_logit = torch.cat([disc_agent_logit, disc_agent_replay_logit], dim=0)
            disc_info = self._disc_loss(disc_agent_cat_logit, disc_demo_logit, amp_obs_demo)
            disc_loss = disc_info['disc_loss']


            loss = a_loss + self.critic_coef * c_loss - self.entropy_coef * entropy + self.bounds_loss_coef * b_loss \
                 + self._disc_coef * disc_loss
            
            if self._reg_loss_enabled:
                reg_loss_info = self._reg_loss()
                reg_loss_v = reg_loss_info['reg_loss']
                loss += reg_loss_v
            
            old = input_dict['kd_mask']
            if getattr(self, '_kd_mode', 'fixed') == 'lagrange':
                per_sample = gaussian_forward_kl_per_sample(mu[old], sigma[old], input_dict['teacher_mu'][old], input_dict['teacher_sigma'][old])
                task = input_dict['obs'][old][:, KD_TASK_ONEHOT].argmax(-1)
                kd_loss, task_kl = lagrange_kd_loss(per_sample, task, self._kd_lambda)
                teacher_kl = per_sample.mean() if per_sample.numel() else mu.sum() * 0
                seen = ~torch.isnan(task_kl)
                self._kd_epoch_kl[seen] += task_kl[seen].detach()
                self._kd_epoch_count[seen] += 1
                loss = loss + kd_loss
            else:
                teacher_kl = gaussian_forward_kl(mu[old], sigma[old], input_dict['teacher_mu'][old], input_dict['teacher_sigma'][old])
                loss = loss + self._kd_coef * teacher_kl
            feature_mse = None
            if getattr(self, '_kd_feature_coef', 0) > 0:  # student feature captured by the hook in self.model(...)
                feature_mse = feature_distill_loss(self._features['student'][old], input_dict['teacher_feature'][old])
                loss = loss + self._kd_feature_coef * feature_mse
            a_info['actor_loss'] = a_loss
            a_info['actor_clip_frac'] = a_clip_frac
            c_info['critic_loss'] = c_loss

            if self.multi_gpu:
                self.optimizer.zero_grad()
            else:
                for param in self.model.parameters():
                    param.grad = None

        self.scaler.scale(loss).backward()
        #TODO: Refactor this ugliest code of the year
        if self.truncate_grads:
            if self.multi_gpu:
                self.optimizer.synchronize()
                self.scaler.unscale_(self.optimizer)
                nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_norm)
                with self.optimizer.skip_synchronize():
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
            else:
                self.scaler.unscale_(self.optimizer)
                nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_norm)
                self.scaler.step(self.optimizer)
                self.scaler.update()    
        else:
            self.scaler.step(self.optimizer)
            self.scaler.update()

        with torch.no_grad():
            reduce_kl = not self.is_rnn
            active = input_dict['push_mask']
            kl_dist = torch_ext.policy_kl(mu[active].detach(), sigma[active].detach(), old_mu_batch[active], old_sigma_batch[active], reduce_kl) if active.any() else mu.sum().detach()*0
            if self.is_rnn:
                kl_dist = (kl_dist * rnn_masks).sum() / rnn_masks.numel()  #/ sum_mask
                    
        self.train_result = {
            'entropy': entropy,
            'kl': kl_dist,
            'last_lr': self.last_lr, 
            'lr_mul': lr_mul, 
            'b_loss': b_loss,
            'teacher_kl': teacher_kl.detach(),
            'push_samples': input_dict['push_mask'].sum().detach()
        }
        if feature_mse is not None:
            self.train_result['feature_mse'] = feature_mse.detach()
        self.train_result.update(a_info)
        self.train_result.update(c_info)
        self.train_result.update(disc_info)
        if self._reg_loss_enabled:
            self.train_result.update(reg_loss_info)

        return
