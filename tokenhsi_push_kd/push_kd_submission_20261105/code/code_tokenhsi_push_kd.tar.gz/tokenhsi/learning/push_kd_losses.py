"""Pure PyTorch losses; no simulator dependency."""
import torch


def gaussian_forward_kl_per_sample(mu, sigma, teacher_mu, teacher_sigma):
    """KL(teacher || student) per sample, summed over actions."""
    tmu, ts = teacher_mu.detach().float(), teacher_sigma.detach().float()
    mu, sigma = mu.float(), sigma.float()
    return (torch.log(sigma / ts) + (ts.square() + (tmu-mu).square()) /
            (2*sigma.square()) - .5).sum(-1)


def gaussian_forward_kl(mu, sigma, teacher_mu, teacher_sigma):
    """KL(teacher || student), sum over actions, mean over samples."""
    if mu.shape[0] == 0:
        return mu.sum() * 0
    return gaussian_forward_kl_per_sample(mu, sigma, teacher_mu, teacher_sigma).mean()


def lagrange_kd_loss(per_sample_kl, task, coef):
    """Per-task weighted KD: sum_k coef_k * (n_k / n) * mean KL_k over tasks k = 0..len(coef)-1.
    With equal coefficients this equals coef * mean KL, i.e. the fixed-coefficient loss.
    Returns (loss, per-task mean KL with NaN for absent tasks)."""
    n = len(coef)
    count = torch.bincount(task, minlength=n).to(per_sample_kl.dtype)
    total = torch.zeros(n, dtype=per_sample_kl.dtype, device=per_sample_kl.device).index_add(0, task, per_sample_kl)
    loss = (coef.to(per_sample_kl.dtype) * total).sum() / count.sum().clamp_min(1)
    mean = torch.where(count > 0, total / count.clamp_min(1), torch.full_like(total, float('nan')))
    return loss, mean


def feature_distill_loss(student_feature, teacher_feature):
    """Mean squared distance between student and frozen-teacher features (mean over dims and samples)."""
    if student_feature.shape[0] == 0:
        return student_feature.sum() * 0
    return (student_feature.float() - teacher_feature.detach().float()).square().mean()


def adapt_coefficient(coef, kl, target, factor, tolerance, low, high):
    """Adaptive KL penalty (Schulman et al. 2017, PPO): double the coefficient when KL exceeds
    tolerance x target, halve it when below target / tolerance. NaN KL (task absent) keeps coef."""
    seen = ~torch.isnan(kl)
    up = seen & (kl > tolerance * target)
    down = seen & (kl < target / tolerance)
    coef = torch.where(up, coef * factor, torch.where(down, coef / factor, coef))
    return coef.clamp(low, high)


def masked_mean(value, mask):
    value = value.reshape(len(mask), -1).mean(-1)
    return value[mask].mean() if mask.any() else value.sum()*0


def push_advantages(returns, values, mask, normalize=True):
    advantage = (returns-values).sum(-1)
    result = torch.zeros_like(advantage)
    selected = advantage[mask]
    if normalize and selected.numel():
        selected = (selected-selected.mean())/(selected.std(unbiased=False)+1e-8)
    result[mask] = selected
    return result


def teacher_observation(obs):
    """397 student -> 354 original: H223 + old task127 + old onehot4."""
    if obs.shape[-1] != 397:
        raise ValueError('Expected TokenHSI PUSH 397D observation')
    return torch.cat((obs[..., :350], obs[..., 392:396]), -1)


def normalize_policy(obs, rms, tasks):
    """Task labels bypass RMS exactly; do not recover labels after clipping."""
    labels = obs[..., -tasks:].clone()
    result = rms(obs)
    result[..., -tasks:] = labels
    return result
