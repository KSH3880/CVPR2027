# TokenHSI PUSH + KD 이관본

실험 목표는 **distillation 범위 안에서 기존 SIT/CARRY/CLIMB 성능 하락 5% 이내와 우리 목표 영역 기준 PUSH final 성공률 >85%를 동시에 만족하는 단일 student `.pth`**다. 현재 나이브 KD 구현의 점검도 포함한다. 평가 정의·탐색 범위·논문용 재현 및 제출 조건은 [실험 요청서](EXPERIMENTS.md), 전달용 문안은 [메시지](MESSAGE.md)를 따른다. 이는 목표이며 현재 달성한 성능이 아니다.

이 폴더 전체 또는 함께 제공한 압축파일을 인턴에게 전달하면 된다. GitHub 계정·clone은 필요 없다. 출처는 `baseline/tokenhsi-push-kd`, commit `0d6d488639429a97611c6bb379603a315e2d2867`이다. 실행 코드·물성·reward·AMP·RSI·KD 설정은 해당 커밋을 유지하며, 이관용 경로 설정과 출력 경로 검사만 추가했다.

포함: 소스, YAML, teacher/초기 student 가중치, 모션·물체·mesh 실제 파일, PUSH RSI 949후보 bank, CPU 테스트. 외부 데이터 심링크와 `.git`은 없다. **Isaac Gym SDK·conda 환경·학습 완료 PUSH 모델·기존 학습 결과는 포함하지 않는다.** Stage1 26k 정책 가중치는 필요 없다. 26k는 환경의 기준이고 teacher/student 초기값은 원본 TokenHSI Stage1이다.

## 1. 환경 준비

Linux/NVIDIA 환경에서 사용한다. 출발 머신의 실제 버전은 Python 3.8.20, torch 2.0.0, numpy 1.21.6, rl-games 1.1.4, gym 0.26.2, Isaac Gym 1.0rc4다. 전체 패키지 참고 목록은 `handoff_support/environment_versions.txt`다. GPU 학습 호환성을 보증하는 lockfile은 아니다. GPU 세대에 맞는 torch/CUDA/Isaac Gym 조합을 별도로 준비한다.

```bash
conda create -n tokenhsi_push python=3.8 -y
conda activate tokenhsi_push
# 서버 GPU/드라이버에 맞는 torch를 먼저 설치한다.
# 별도 제공받은 Isaac Gym Preview 4 SDK의 python 폴더를 지정한다.
pip install -e /absolute/path/to/isaacgym/python
# 이후 이 README가 있는 폴더로 이동한다.
pip install -r requirements.txt
pip install PyYAML tensorboard tensorboardX
export LD_LIBRARY_PATH="$CONDA_PREFIX/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export OMP_NUM_THREADS=1
```

Isaac Gym SDK는 수신자가 별도로 준비한다. Python에서 직접 확인할 때는 `import isaacgym`을 `import torch`보다 먼저 실행한다. 설치 확인:

```bash
python -c 'import isaacgym; import torch; print(torch.__version__, torch.cuda.is_available())'
```

## 2. 폴더 검증과 경로 설정

아래 명령은 항상 이 README가 있는 폴더에서 실행한다. 폴더를 다시 옮기면 `prepare_paths.py`를 다시 실행한다. 모션 manifest 세 개의 경로만 현재 위치로 갱신하며 모션·보상·분포는 바꾸지 않는다. 수동으로 과거 `/home/inkyu/...` 경로를 만들 필요 없다.

```bash
python scripts/verify_bundle.py
python scripts/prepare_paths.py
python -m pytest -q tests --basetemp=output_etc/check/pytest_tmp -o cache_dir=output_etc/check/pytest_cache
```

`prepare_paths.py`는 원본 preflight도 실행하여 PUSH 모션 hash·mesh·949후보 계약·가중치 존재를 확인한다. 무결성 목록은 경로가 바뀌는 runtime manifest 세 개와 검증 결과 파일을 제외하며, 원본 데이터와 경로 template은 포함한다.

## 3. 짧은 통합 확인 → 본학습

먼저 `nvidia-smi`로 GPU 점유를 확인한다. 기존 프로세스는 종료하지 않는다. 아래 GPU 번호는 사용할 수 있는 번호로 바꾼다. CPU 검사를 통과한 뒤 GPU PPO 통합을 확인한다. 기본은 참조 2048scene(2명/4상자) + native KD 2048환경이며 6144 policy row다. 짧은 검사도 이 규모를 유지한다.

```bash
mkdir -p output_etc/check
TOKENHSI_GPU=0 MAX_ITERATIONS=1 OUTPUT_PATH=output_etc/check/smoke bash scripts/train.sh > output_etc/check/smoke.log 2>&1

# 통합 검사 성공 후 본학습. 확인용 제한 변수를 제거한다.
unset CHECK MAX_ITERATIONS RESUME_CHECKPOINT OUTPUT_PATH
TOKENHSI_GPU=0 OUTPUT_PATH=output/push_kd_seed42 SEED=42 bash scripts/train.sh

# 동일 설정 checkpoint에서 재개할 때만 사용한다.
TOKENHSI_GPU=0 RESUME_CHECKPOINT=/absolute/student.pth OUTPUT_PATH=output/push_kd_seed42 SEED=42 bash scripts/train.sh
```

`CHECK=1`은 1 epoch 확인 실행으로 처리한다. `CHECK` 또는 `MAX_ITERATIONS` 실행은 출력이 `output_etc/check/` 아래인지 검사한다. 본학습은 기본 26000 epoch, KD 계수는 `tokenhsi/data/cfg/train/rlg/push_kd.yaml`의 `kd_coef: 0.001`이다. teacher/RMS는 고정, PUSH만 PPO+AMP, native SIT/CARRY/CLIMB만 forward KL, TRAJ는 제외한다.

선택 CPU 물리 연결 확인(학습 아님, GPU 본학습 검증을 대신하지 않음):

```bash
TORCH_EXTENSIONS_DIR="$PWD/output_etc/check/torch_extensions" python scripts/check_reference_cpu.py mixed > output_etc/check/cpu_mixed.log 2>&1
TORCH_EXTENSIONS_DIR="$PWD/output_etc/check/torch_extensions" python scripts/check_reference_cpu.py policy > output_etc/check/cpu_policy.log 2>&1
```

## 4. 평가와 전달 결과

평가는 student만 사용한다. **기존 과제는 TokenHSI 원본 eval, PUSH 목표는 우리 목표 영역 기준 final >85%이며 ever도 발표용으로 함께 보고한다.** 현재 baseline PUSH eval과 요청한 영역 판정의 차이는 [EVALUATION.md](EVALUATION.md)를 확인한다. 기본 headless 512scene이며 PUSH는 loco-only다. 초기 보존 성능은 `weights/push_init.pth`, 학습 후 성능은 저장 student로 각각 평가한다.

```bash
TOKENHSI_GPU=0 CHECKPOINT=/absolute/student.pth EVAL_TASK=push SEED=0 bash scripts/eval.sh > output_etc/check/eval_push_seed0.log 2>&1
# PUSH JSON은 매번 덮어쓰므로 즉시 별도 보존한다.
cp output_etc/check/push_eval.json output_etc/check/student_push_seed0.json
TOKENHSI_GPU=0 CHECKPOINT=/absolute/student.pth EVAL_TASK=sit SEED=0 bash scripts/eval.sh > output_etc/check/eval_sit_seed0.log 2>&1
TOKENHSI_GPU=0 CHECKPOINT=/absolute/student.pth EVAL_TASK=carry SEED=0 bash scripts/eval.sh > output_etc/check/eval_carry_seed0.log 2>&1
TOKENHSI_GPU=0 CHECKPOINT=/absolute/student.pth EVAL_TASK=climb SEED=0 bash scripts/eval.sh > output_etc/check/eval_climb_seed0.log 2>&1
```

이관 확인 결과는 `HANDOFF_VALIDATION.md`, 실험 요청·기록 양식은 [EXPERIMENTS.md](EXPERIMENTS.md), 상세 방법은 [METHOD.md](METHOD.md), 원래 실행 안내는 [UPSTREAM_README.md](docs/UPSTREAM_README.md)를 참고한다. 원본 문서의 머신 절대경로는 출처 기록이다. GPU PPO 통합·장기 학습·성공률은 이관 작업에서 검증하지 않았다.
