"""Lagrange (adaptive per-task coefficient) KD: loss reduces to the fixed-coefficient loss when the
coefficients are equal, per-task KL is reported per task, and the coefficient update follows the
adaptive KL penalty rule."""
import math

import torch

from learning.push_kd_losses import (adapt_coefficient, gaussian_forward_kl, gaussian_forward_kl_per_sample,
                                     lagrange_kd_loss)


def _sample(n=12, actions=32, seed=0):
    g = torch.Generator().manual_seed(seed)
    mu = torch.randn(n, actions, generator=g, requires_grad=True)
    teacher_mu = torch.randn(n, actions, generator=g)
    sigma = torch.full((n, actions), 0.055)
    return mu, sigma, teacher_mu, sigma.clone()


def test_equal_coefficients_match_fixed_loss():
    mu, sigma, tmu, ts = _sample()
    task = torch.tensor([0, 1, 2] * 4)
    per = gaussian_forward_kl_per_sample(mu, sigma, tmu, ts)
    loss, _ = lagrange_kd_loss(per, task, torch.full((3,), 0.001))
    assert torch.allclose(loss, 0.001 * gaussian_forward_kl(mu, sigma, tmu, ts))


def test_per_task_mean_and_absent_task():
    per = torch.tensor([1., 3., 10., 20.])
    task = torch.tensor([0, 0, 2, 2])
    loss, mean = lagrange_kd_loss(per, task, torch.tensor([1., 1., 2.]))
    assert mean[0] == 2 and math.isnan(mean[1]) and mean[2] == 15
    assert torch.isclose(loss, torch.tensor((1 * 4 + 2 * 30) / 4))


def test_gradient_scales_with_task_coefficient():
    mu, sigma, tmu, ts = _sample(n=2)
    task = torch.tensor([0, 1])
    per = gaussian_forward_kl_per_sample(mu, sigma, tmu, ts)
    loss, _ = lagrange_kd_loss(per, task, torch.tensor([1., 0., 0.]))
    loss.backward()
    assert mu.grad[0].abs().sum() > 0 and mu.grad[1].abs().sum() == 0


def test_adaptive_rule():
    coef = torch.tensor([0.01, 0.01, 0.01, 0.01, 8.0, 1.5e-4])
    kl = torch.tensor([4.0, 0.5, 1.2, float('nan'), 9.0, 0.1])  # target 1, tolerance 1.5
    new = adapt_coefficient(coef, kl, target=1.0, factor=2.0, tolerance=1.5, low=1e-4, high=10.0)
    expected = torch.tensor([0.02, 0.005, 0.01, 0.01, 10.0, 1e-4])  # up, down, hold, absent, clamp high, clamp low
    assert torch.allclose(new, expected)


def test_feature_distill_loss():
    from learning.push_kd_losses import feature_distill_loss
    s = torch.tensor([[1., 3.], [0., 0.]], requires_grad=True)
    t = torch.tensor([[0., 1.], [0., 0.]], requires_grad=True)
    loss = feature_distill_loss(s, t)
    assert torch.isclose(loss, torch.tensor((1 + 4 + 0 + 0) / 4))
    loss.backward()
    assert t.grad is None or (t.grad == 0).all()  # teacher feature is a fixed target
    assert feature_distill_loss(s[:0], t[:0]) == 0
