"""AMP demo/replay memory fix: the per-epoch batch_size draw shrinks to one minibatch, and each
minibatch draws amp_minibatch_size fresh demo/replay rows from the buffers (PUSH samples while the
replay buffer is still empty), matching what the original read at shuffled AMPDataset indices."""
import ast
from pathlib import Path
from types import SimpleNamespace

import torch

BATCH, AMP_MINIBATCH = 96, 8


def _methods(*names):
    # Same approach as test_optimizer_routing: take methods from source without importing Isaac Gym.
    path = Path(__file__).resolve().parents[1]/'tokenhsi/learning/push_kd_agent.py'
    cls = next(x for x in ast.parse(path.read_text()).body if isinstance(x, ast.ClassDef))
    body = [x for x in cls.body if isinstance(x, ast.FunctionDef) and x.name in names]
    namespace = {}
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'), namespace)
    return SimpleNamespace(**{name: namespace[name] for name in names})


M = _methods('_amp_rows', '_amp_minibatch')


class Buffer:
    def __init__(self, fill, total):
        self.fill, self.total, self.calls = fill, total, []
    def get_total_count(self):
        return self.total
    def sample(self, n):
        self.calls.append(n)
        return {'amp_obs': torch.full((n, 1340), float(self.fill))}


def _agent(used_rows, replay_total):
    agent = SimpleNamespace(batch_size=BATCH, _amp_minibatch_size=AMP_MINIBATCH, _amp_used_rows=used_rows, ppo_device='cpu',
                            _amp_obs_demo_buffer=Buffer(1, 500), _amp_replay_buffer=Buffer(2, replay_total),
                            _sample_push_amp=lambda n: torch.full((n, 1340), 3.))
    return agent


def test_epoch_draw_shrinks_only_when_on():
    assert M._amp_rows(_agent(True, 0), BATCH) == AMP_MINIBATCH
    assert M._amp_rows(_agent(True, 0), 50) == 50  # other sizes untouched
    assert M._amp_rows(_agent(False, 0), BATCH) == BATCH


def test_minibatch_draws_from_buffers():
    agent = _agent(True, replay_total=100)
    demo, replay = M._amp_minibatch(agent)
    assert demo.shape == replay.shape == (AMP_MINIBATCH, 1340)
    assert (demo == 1).all() and (replay == 2).all()
    assert agent._amp_obs_demo_buffer.calls == [AMP_MINIBATCH] and agent._amp_replay_buffer.calls == [AMP_MINIBATCH]


def test_first_epoch_replay_uses_push_samples():
    agent = _agent(True, replay_total=0)
    _, replay = M._amp_minibatch(agent)
    assert (replay == 3).all() and agent._amp_replay_buffer.calls == []
