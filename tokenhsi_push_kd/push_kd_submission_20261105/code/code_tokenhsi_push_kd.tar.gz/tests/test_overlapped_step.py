"""MixedReferenceEnv.step overlaps the native worker with the reference simulator: the native step is sent
first and received after the reference step. The two pools share no state, so every output must equal what
the sequential order (reference step, then native step) produces."""
import ast
from pathlib import Path
from types import SimpleNamespace

import torch

ROOT = Path(__file__).resolve().parents[1]
N_REF, N_NATIVE = 3, 4   # reference scenes (two rows each) and native envs


def _method(path, cls_name, name, namespace):
    # Same approach as test_optimizer_routing: take the method from source without importing Isaac Gym.
    tree = ast.parse((ROOT/path).read_text())
    cls = next(x for x in tree.body if isinstance(x, ast.ClassDef) and x.name == cls_name)
    body = [x for x in cls.body if isinstance(x, ast.FunctionDef) and x.name == name]
    exec(compile(ast.Module(body=body, type_ignores=[]), path, 'exec'), namespace)
    return namespace[name]


class Reference:
    def __init__(self, log):
        self.log = log
    def step(self, actions):
        self.log.append('reference step')
        a = actions.sum(-1).reshape(N_REF, 2)
        self.rew_buf, self._terminate_buf = a, a > 0
        self.reset_buf = (a[:, 0] > 0).long()
        self.extras = {'amp_obs': actions.repeat(1, 42)[:, :1340]}
        self.relation_runtime = SimpleNamespace(done=a < 0)
        self._box_states = torch.stack((a, -a, a), -1)
        self._tar_pos = torch.zeros(N_REF, 2, 3)


class Native:
    def __init__(self, log):
        self.log, self.pending = log, None
    def send_step(self, actions):
        self.log.append('native send')
        self.pending = actions.clone()
    def wait_step(self):
        self.log.append('native wait')
        a = self.pending
        self.obs_buf = a.repeat(1, 12)[:, :354]
        self.rew_buf, self.reset_buf = a[:, 0], (a[:, 1] > 0).long()
        self._terminate_buf, self._success_buf, self._precision_buf = a[:, 2] > 0, a[:, 3] > 0, a[:, 4]
        self.extras = {'amp_obs': a.repeat(1, 42)[:, :1330]}
    def step(self, actions):
        self.send_step(actions)
        self.wait_step()


def _env(log):
    env = SimpleNamespace(reference=Reference(log), native=Native(log), reference_rows=2*N_REF, rl_device='cpu',
                          num_envs=2*N_REF+N_NATIVE, _projection_reset=None, _ever=torch.zeros(2*N_REF, dtype=torch.bool))
    project = lambda ref, reset: torch.cat((ref.rew_buf.reshape(-1, 1).expand(-1, 392), torch.eye(5)[torch.arange(2*N_REF) % 5]), -1)
    namespace = dict(torch=torch, project=project, amp_to_tokenhsi=lambda x: x)
    env._obs = _method('tokenhsi/env/mixed_reference_env.py', 'MixedReferenceEnv', '_obs', namespace).__get__(env)
    env.step = _method('tokenhsi/env/mixed_reference_env.py', 'MixedReferenceEnv', 'step', namespace).__get__(env)
    return env


def _sequential(env, actions):
    """The order used before the overlap: reference step, then a blocking native step."""
    ref, nat = env.reference, env.native
    ref.step(actions[:env.reference_rows].clamp(-1, 1))
    nat.step(actions[env.reference_rows:].clamp(-1, 1))
    obs = env._obs()
    amp = nat.extras['amp_obs'].reshape(-1, 10, 133)
    return dict(obs=obs,
                reward=torch.cat((ref.rew_buf.flatten(), torch.zeros_like(nat.rew_buf))),
                done=torch.cat((ref.reset_buf.repeat_interleave(2), nat.reset_buf)),
                amp=torch.cat((ref.extras['amp_obs'], torch.cat((amp, amp.new_zeros(*amp.shape[:-1], 1)), -1).flatten(1))),
                terminate=torch.cat((ref._terminate_buf.flatten(), nat._terminate_buf)),
                success=torch.cat((ref.relation_runtime.done.flatten(), nat._success_buf)),
                precision=torch.cat(((ref._box_states[:, :2, :2]-ref._tar_pos[..., :2]).norm(dim=-1).flatten(), nat._precision_buf)))


def test_native_step_is_sent_before_the_reference_step_and_received_after():
    log = []
    env = _env(log)
    env.step(torch.randn(env.num_envs, 32))
    assert log == ['native send', 'reference step', 'native wait']


def test_overlapped_step_matches_sequential_order():
    torch.manual_seed(0)
    for _ in range(3):
        actions = 2*torch.randn(2*N_REF+N_NATIVE, 32)
        obs, reward, done, info = _env([]).step(actions)
        expected = _sequential(_env([]), actions)
        torch.testing.assert_close(obs, expected['obs'])
        torch.testing.assert_close(reward, expected['reward'])
        torch.testing.assert_close(done, expected['done'])
        for key in ('amp', 'terminate', 'success', 'precision'):
            torch.testing.assert_close(info['amp_obs' if key == 'amp' else key], expected[key])
