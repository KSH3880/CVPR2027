"""Teacher baseline on the ORIGINAL TokenHSI code, with the same warm-up as the student eval.

The original checkout is not modified: its player's run_eval is wrapped in-process, then
tokenhsi/run.py runs with the arguments of the original scripts/tokenhsi/stage1_eval.sh.

    ORIG_ROOT=/path/to/TokenHSI EVAL_TASK=climb SEED=0 python scripts/eval_teacher_original.py

ORIG_ROOT must hold the original code with its datasets and output/tokenhsi/ckpt_stage1.pth.
NATIVE_EVAL_WARMUP=0 reproduces the unmodified original eval.
"""
import importlib.util
import os
import runpy
import sys

import isaacgym  # must precede torch

bundle = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location(
    'native_eval_warmup', os.path.join(bundle, 'tokenhsi/learning/native_eval_warmup.py'))
warmup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(warmup)

root = os.path.abspath(os.environ['ORIG_ROOT'])
os.chdir(root)
sys.path.insert(0, os.path.join(root, 'tokenhsi'))
from learning.transformer import trans_players  # the original player

original_run_eval = trans_players.TransPlayerContinuous.run_eval


def run_eval(self):
    steps = warmup.warmup_steps()
    if steps > 0:
        warmup.run_warmup(self, steps)
    return original_run_eval(self)


trans_players.TransPlayerContinuous.run_eval = run_eval

sys.argv = ['tokenhsi/run.py', '--task', 'HumanoidTrajSitCarryClimb',
            '--cfg_train', 'tokenhsi/data/cfg/train/rlg/amp_imitation_task_transformer_multi_task.yaml',
            '--cfg_env', 'tokenhsi/data/cfg/multi_task/amp_humanoid_traj_sit_carry_climb.yaml',
            '--motion_file', 'tokenhsi/data/dataset_loco_sit_carry_climb.yaml',
            '--checkpoint', os.environ.get('CHECKPOINT', 'output/tokenhsi/ckpt_stage1.pth'),
            '--test', '--num_envs', os.environ.get('NUM_ENVS', '512'), '--headless',
            '--eval', '--eval_task', os.environ['EVAL_TASK'], '--seed', os.environ.get('SEED', '0')]
runpy.run_path('tokenhsi/run.py', run_name='__main__')
